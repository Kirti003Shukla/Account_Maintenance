<?php
session_start();
   include("config.php");
   
            if(!isset($_SESSION['user']))
            {header("location:index.php");}

if($_SERVER["REQUEST_METHOD"] == "POST") {
        $customer_name = strtoupper(mysqli_escape_string($db,$_POST['customer_name']));  
        $customer_phone = mysqli_escape_string($db,$_POST['customer_phone']);

  	$sql_p = "SELECT * FROM customer WHERE customer_phone= $customer_phone";
  	$res_p = mysqli_query($db, $sql_p);

  	if (mysqli_num_rows($res_p) > 0) {
  	  $name_error = "Sorry... phone number already taken"; 	
  	}else
         {$query = "INSERT INTO customer (customer_name, customer_phone) 
  			  VALUES('$customer_name', '$customer_phone')";
    	mysqli_query($db, $query);
    	header("location:dashboard.php");
    	exit();
}
    
} ?>
 

<!DOCTYPE html>
<html><head>
    <style>
            /*Main CSS*/



form {
  width: 40%;
  margin: 40px auto;
  background: #efefef;
  padding: 60px 120px 80px 120px;
  text-align: center;
  -webkit-box-shadow: 2px 2px 3px rgba(0,0,0,0.1);
  box-shadow: 2px 2px 3px rgba(0,0,0,0.1);
}
label {
  display: block;
  position: relative;
  margin: 40px 0px;
}
.label-txt {
  position: absolute;
  top: -1.6em;
  padding: 10px;
  font-family: sans-serif;
  font-size: .8em;
  letter-spacing: 1px;
  color: rgb(120,120,120);
  transition: ease .3s;
}
.input {
  width: 100%;
  padding: 10px;
  background: transparent;
  border: none;
  outline: none;
}

.line-box {
  position: relative;
  width: 100%;
  height: 2px;
  background: #BCBCBC;
}

.line {
  position: absolute;
  width: 0%;
  height: 2px;
  top: 0px;
  left: 50%;
  transform: translateX(-50%);
  background: white;
  transition: ease .6s;
}

.input:focus + .line-box .line {
  width: 100%;
}

.label-active {
  top: -3em;
}

button {
  display: inline-block;
  padding: 12px 24px;
  background: rgb(220,220,220);
  font-weight: bold;
  color: rgb(120,120,120);
  border: none;
  outline: none;
  border-radius: 3px;
  cursor: pointer;
  transition: ease .3s;
}

button:hover {
  background: white;
  color: #ffffff;
}

  
        </style>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

    </head>
<body class="home">
    
    <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav mt-2 mt-lg-0">
        <li><a href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <!--<li><a href="#"><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>-->
                        <!--<li><a href="#"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>-->
                        <li class="active"><a href="addCustomer.php"><i class="fa fa-user" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Add Customer</span></a></li>
                        <li ><a href="viewCustomer.php"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">View Customer</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
           
    </ul>
       

  </div>
</nav><br>
        <div style="clear:both"></div>
<br>
 <form method="post" action="">
     <div class="form-group">
  
    <!--<p class="label-txt">Customer Name</p>-->
<input type="text" name="customer_name" placeholder="Customer Name"  class="form-control" required />
<!--<div class="line-box">-->
<!--      <div class="line"></div>-->
<!--    </div>-->
  
  </div>
    <div class="form-group">

  
    <!--<p class="label-txt">Phone Number</p>-->
<input type="number" name="customer_phone" max="9999999999" min="1000000000"
                                    placeholder="Enter 10 digit Phone Number" class="form-control" required/>
                                    	  <?php if (isset($name_error)){ ?>
	  	                             <span><?php echo $name_error;} ?></span> 
	  	<!--                             <div class="line-box">-->
    <!--  <div class="line"></div>-->
    <!--</div>-->
  
  </div>
                                        <button class="btn btn-lg">Save</button>

</form>





   

<script>
$(document).ready(function(){
   $('[data-toggle="offcanvas"]').click(function(){
       $("#navigation").toggleClass("hidden-xs");
   });
});
</script>
 <script>
       $(document).ready(function(){

  $('.input').focus(function(){
    $(this).parent().find(".label-txt").addClass('label-active');
  });

  $(".input").focusout(function(){
    if ($(this).val() == '') {
      $(this).parent().find(".label-txt").removeClass('label-active');
    };
  });

});
   </script> 


</body>
</html>