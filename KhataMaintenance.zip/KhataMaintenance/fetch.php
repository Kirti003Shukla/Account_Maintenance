<?php
include('config.php');
    setlocale(LC_MONETARY, 'en_IN');

$output = '';
if(isset($_POST["query"]))

{
    
	$search = mysqli_real_escape_string($db, $_POST["query"]);
	$query = "
	SELECT * FROM customer 
	WHERE customer_name LIKE '%".$search."%'
	OR customer_phone LIKE '%".$search."%' 
	";
}
else
{
	$query = "SELECT * FROM customer ORDER BY customer_name";
}
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<div class="table-responsive">
					<table class="table tbl-hover">
						<tr>
	<th bgcolor="#4A484C">Name</th>
   <th bgcolor="#4A484C">Phone No</th>
  <th bgcolor="#4A484C">Action</th>
    <th bgcolor="#4A484C">Total</th>

						</tr>';
		
	while($row = mysqli_fetch_array($result))
	{
	      $customer_Id=$row['customer_id'];
                 $sql_Sent = "SELECT SUM(transaction_sent) AS sent FROM transaction_detail where customer_id=$customer_Id";  
$result_Sent = mysqli_query($db,$sql_Sent); 
$sql_Receive = "SELECT SUM(transaction_receive) AS receive FROM transaction_detail where customer_id=$customer_Id";  
$result_Receive = mysqli_query($db,$sql_Receive); 

while ($row_Sent = mysqli_fetch_assoc($result_Sent)){
    $sum_Sent += $row_Sent['sent']; 
}


while ($row_Receive = mysqli_fetch_assoc($result_Receive)){
    $sum_Receive += $row_Receive['receive'];
}


 $total = $sum_Receive-$sum_Sent;
 unset($sum_Sent);    unset($sum_Receive);
 $classname = intval($total) < 0 ? 'negative' : 'positive';
		$output .= '
			<tr onClick=window.location.replace("transactions.php?customer_id='.$customer_Id.'")
			style="cursor: pointer;">
				<td>'.$row["customer_name"].'</td>
				<td>'.$row["customer_phone"].'</td>
            				<td><a href="transactions.php?customer_id='.$customer_Id.'">Transactions</a></td>

				<td class="value-'.$classname.'">'.$amount = money_format('%!i', $total);$amount.'</td>
						</tr>';
		unset($amount);
		


	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>