<?php
session_start();
   include("config.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {
         $user = mysqli_escape_string($db,$_POST['user']);  
         $pass = mysqli_escape_string($db,$_POST['pass']);
        if ($user=='admin')   
       { 
            //declaring session  
    
             $_SESSION['user']=$user;

           header("location: dashboard.php");

        }  
        else{  
            echo 'Your Account is Invalid';  
        }  
    
} 

?>


<!DOCTYPE html>  
<html>  
<head>  
    <title>Login</title>  
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style>
    

body {
}
form {
  width: 40%;
  margin: 40px auto;
  background: #efefef;
  padding: 60px 120px 80px 120px;
  text-align: center;
  -webkit-box-shadow: 2px 2px 3px rgba(0,0,0,0.1);
  box-shadow: 2px 2px 3px rgba(0,0,0,0.1);
}
label {
  display: block;
  position: relative;
  margin: 40px 0px;
}
.label-txt {
  position: absolute;
  top: -1.6em;
  padding: 10px;
  font-family: sans-serif;
  font-size: .8em;
  letter-spacing: 1px;
  color: rgb(120,120,120);
  transition: ease .3s;
}
.input {
  width: 100%;
  padding: 10px;
  background: transparent;
  border: none;
  outline: none;
}

.line-box {
  position: relative;
  width: 100%;
  height: 2px;
  background: #BCBCBC;
}

.line {
  position: absolute;
  width: 0%;
  height: 2px;
  top: 0px;
  left: 50%;
  transform: translateX(-50%);
  background: white;
  transition: ease .6s;
}

.input:focus + .line-box .line {
  width: 100%;
}

.label-active {
  top: -3em;
}

button {
  display: inline-block;
  padding: 12px 24px;
  background: rgb(220,220,220);
  font-weight: bold;
  color: rgb(120,120,120);
  border: none;
  outline: none;
  border-radius: 3px;
  cursor: pointer;
  transition: ease .3s;
}

button:hover {
  background: #8BC34A;
  color: #ffffff;
}

</style>
</head>  
<body>  

<form method="post" action="">
  <label>
    <p class="label-txt">USERNAME <i class="fa fa-user" aria-hidden="true"></i>
</p>
<input type="text" name="user" class="input" required>   <div class="line-box">      <div class="line"></div>
    </div>
  </label>
  
  <label>
    <p class="label-txt">PASSWORD <i class="fa fa-lock" aria-hidden="true"></i></p>
<input type="password" name="pass"class="input" required>
    <div class="line-box">
      <div class="line"></div>
    </div>
  </label>
                    <button class="btn btn-lg btn-primary" type="submit">Login</button>
    <p>USERNAME- admin</p>
    <p>PASSWORD- 123456</p>
</form>
    

   <script>
       $(document).ready(function(){

  $('.input').focus(function(){
    $(this).parent().find(".label-txt").addClass('label-active');
  });

  $(".input").focusout(function(){
    if ($(this).val() == '') {
      $(this).parent().find(".label-txt").removeClass('label-active');
    };
  });

});
   </script> 
</body>  

</html>  
