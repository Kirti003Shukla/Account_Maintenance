<?php
include('config.php');
setlocale(LC_MONETARY, 'en_IN');

$output = '';
if(isset($_POST["query"])&& isset($_POST["customerId"]))

{     $page=  mysqli_real_escape_string($db,$_POST['customerId']);

    
	 $search = mysqli_real_escape_string($db, $_POST["query"]);
	$query = "
	SELECT * FROM transaction_detail
	where customer_id= $page AND  YEAR(transaction_date) = $search";
// 	LIKE 
// 	'%".$search."%'
// 	";
}
else if(isset($_POST["customerId"]))

{
         $page=  mysqli_real_escape_string($db,$_POST['customerId']);                
$query = "SELECT * FROM transaction_detail where customer_id= $page ORDER BY `transaction_date` ";
$rs_result = mysqli_query($db,$query); 
$last_id = mysqli_insert_id($db);
    
}
$result = mysqli_query($db, $query);
if(mysqli_num_rows($result) > 0)
{
    $sqlName = "SELECT customer_name, customer_phone FROM customer where customer_id= $page";
$rs_Name = mysqli_query($db,$sqlName); 
while ($row_Name = mysqli_fetch_assoc($rs_Name)){
    $sum_Name = $row_Name['customer_name'];
    $sum_Phone = $row_Name['customer_phone'];
}

	$output .= '<h3 style="display:inline">'. $sum_Name.'/</h3>
<h3 style="display:inline">'.$sum_Phone.'</h3>';
	$output .= '<div class="box-body table-responsive no-padding">
<table class="table table-hover table-bordered">
<tr>
<th bgcolor="#D5B32E"><strong>Date</strong></th>
<th bgcolor="#D5B32E"><strong>Items</strong></th>
<th bgcolor="#D5B32E"><strong>Diya</strong></th>
<th bgcolor="#D5B32E"><strong>Liya</strong></th>
<th bgcolor="#D5B32E"><strong>Total</strong></th>
<th bgcolor="#D5B32E"><strong>Action</strong></th>
</tr>';
		
	while($row = mysqli_fetch_array($result))
	{$currentDate =$row["transaction_date"];
	      $customer_Id=$row['customer_id'];
	       $t_id = $row["transaction_id"];

                 $sql_Sent = "SELECT SUM(transaction_sent) AS sent FROM transaction_detail where customer_id=$customer_Id";  
$result_Sent = mysqli_query($db,$sql_Sent); 
$sql_Receive = "SELECT SUM(transaction_receive) AS receive FROM transaction_detail where customer_id=$customer_Id";  
$result_Receive = mysqli_query($db,$sql_Receive); 

while ($row_Sent = mysqli_fetch_assoc($result_Sent)){
    $sum_Sent += $row_Sent['sent']; 
}


while ($row_Receive = mysqli_fetch_assoc($result_Receive)){
    $sum_Receive += $row_Receive['receive'];
}


 $total = $sum_Receive-$sum_Sent;
 unset($sum_Sent);    unset($sum_Receive);
 
		$output .= '<tr><td>'.date("d-m-Y", strtotime($row["transaction_date"])).'</td>
<td>'.strtoupper($row["transaction_detail"]).'</td>';
$amountS = money_format('%!i', $row["transaction_sent"]);

	$output .= '<td class="colo">'. $amountS .'</td>';
$amountR = money_format('%!i', $row["transaction_receive"]);
$output .= '<td class="col">'. $amountR.'</td>';
$sql_Re = "SELECT SUM(transaction_receive)-SUM(transaction_sent) AS re FROM transaction_detail where transaction_date<'$currentDate' AND customer_id=$page";  
$result_Re = mysqli_query($db,$sql_Re); 
while ($row_St = mysqli_fetch_assoc($result_Re)){
   $sum_St = $row_St['re'];
}
$amountT = money_format('%!i', ($sum_St+($row["transaction_receive"]-$row["transaction_sent"])));
            $classname = intval($amountT) < 0 ? 'negative' : 'positive';

$output .= '<td class="value-'.$classname.'">'.$amountT.'
</td>
<td>
<a onclick="return confirm('."Delete this record?".')"
href="deleterecord.php?customer_id='.$customer_Id.'&t_id='.$t_id.'">Delete</a>
</td>
</tr>';
		
unset($amountT);

	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>