<?php
include('config.php');
if(isset($_POST['contactFrmSubmit']) && !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])){
    
    // Submitted form data
    $amount   =  mysqli_real_escape_string($db,$_POST['name']);
    $item  =  mysqli_real_escape_string($db,$_POST['email']);
    $date=  mysqli_real_escape_string($db,$_POST['message']);
    $customer_id=  mysqli_real_escape_string($db,$_POST['customer']);

    
     
  $t=time();


$datetotime = (date("H:i:s",$t));
$combinedDT = date('Y-m-d H:i:s', strtotime("$date $datetotime"));


  	$query = "INSERT INTO transaction_detail (customer_id,transaction_sent,transaction_detail,transaction_date) 
  			  VALUES('$customer_id','$amount', '$item', '$combinedDT')";
  	mysqli_query($db, $query);

    if(mysqli_affected_rows($db))
{
        $status = 'ok';
}else{
        $status = 'err';
    }
    
    // Output status
    echo $status;die;
 }
 
 if(isset($_POST['receiveFrmSubmit']) && !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])){
    
    // Submitted form data
    $amountR   =  mysqli_real_escape_string($db,$_POST['name']);
    $itemR  =  mysqli_real_escape_string($db,$_POST['email']);
    $dateR=  mysqli_real_escape_string($db,$_POST['message']);
    $customer_id=  mysqli_real_escape_string($db,$_POST['customer']);

     
   $t=time();


$datetotime = (date("H:i:s",$t));
$combinedDT = date('Y-m-d H:i:s', strtotime("$dateR $datetotime"));

  	$query = "INSERT INTO transaction_detail (customer_id,transaction_receive,transaction_detail,transaction_date) 
  			  VALUES('$customer_id','$amountR', '$itemR', '$combinedDT')";
  	mysqli_query($db, $query);

    if(mysqli_affected_rows($db))
{
        $status = 'ok';
}else{
        $status = 'err';
    }
    
    // Output status
    echo $status;


    
 }

 
 if(isset($_POST['editFrmSubmit']) && !empty($_POST['name']) && !empty($_POST['number'])){
    
    // Submitted form data
     $customer_name = strtoupper(mysqli_escape_string($db,$_POST['name']));  
    $customer_phone = mysqli_escape_string($db,$_POST['number']);
    $customer_id=  mysqli_real_escape_string($db,$_POST['customer']);

     	$querySelect = "SELECT customer_phone FROM `customer` WHERE `customer_phone`= $customer_phone AND customer_id !=$customer_id";
  	mysqli_query($db, $querySelect);

    if(mysqli_affected_rows($db))
{
        $status = 'err';
}else{
$query = 'UPDATE `customer` SET `customer_name`="'.$customer_name.'",`customer_phone`= "'.$customer_phone.'" WHERE customer_id="'.$customer_id.'"';
  	mysqli_query($db, $query);

    if(mysqli_affected_rows($db))
{
        $status = 'ok';
}else{
        $status = 'err';
    }    
    

    
} 
    // Output status
    echo $status;

}

//delete request
if((isset($_POST['deleteFrmSubmit'])) && !empty($_POST['startDate']) && !empty($_POST['endDate'])&& !empty($_POST['customer'])){
    
    // Submitted form data
      

$firstDate = mysqli_real_escape_string($db,$_POST['startDate']);
$firstDate .= " 00:00:00";
// $firstDate = date('Y-m-d H:i:s', strtotime("$date $datetotime"));
    
    // $firstDate   = date('Y-m-d', strtotime($_POST['startDate']));
        
        $lastDate = mysqli_real_escape_string($db,$_POST['endDate']);
$lastDate .= " 23:59:59";
// $lastDate = date('Y-m-d H:i:s', strtotime("$datE $datetotimE"));

    //   $lastDate =  date("Y-m-d", strtotime($_POST['endDate']));
    // $lastDate .= ' 23:59:59';


    $customer_id=  mysqli_real_escape_string($db,$_POST['customer']);
    

    $query = "DELETE FROM transaction_detail  WHERE  customer_id=$customer_id AND transaction_date BETWEEN '$firstDate' AND '$lastDate'";

     


  	mysqli_query($db, $query);

    if(mysqli_affected_rows($db))
{
        $status = 'ok';
}else{
        $status = 'err';
    }
    
    // Output status
    echo $status;
 }
