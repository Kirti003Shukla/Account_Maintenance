<?php
   session_start();

   include("config.php");
            if(!isset($_SESSION['user']))
            header("location:index.php");

setlocale(LC_MONETARY, 'en_IN');

   if (isset($_GET["customer_id"]))
    {  $page = $_GET["customer_id"]; }
    
 $sqlName = "SELECT customer_name, customer_phone FROM customer where customer_id= $page";
$rs_Name = mysqli_query($db,$sqlName); 
while ($row_Name = mysqli_fetch_assoc($rs_Name)){
    $sum_Name = $row_Name['customer_name'];
    $sum_Phone = $row_Name['customer_phone'];
}

 
    
$sql_Sent = "SELECT SUM(transaction_sent) AS sent FROM transaction_detail where customer_id=$page";  
$result_Sent = mysqli_query($db,$sql_Sent); 
$sql_Receive = "SELECT SUM(transaction_receive) AS receive FROM transaction_detail where customer_id=$page";  
$result_Receive = mysqli_query($db,$sql_Receive); 

while ($row_Sent = mysqli_fetch_assoc($result_Sent)){
   $sum_Sent = $row_Sent['sent'];
}


while ($row_Receive = mysqli_fetch_assoc($result_Receive)){
    $sum_Receive = $row_Receive['receive'];
}


$total = ($sum_Receive-$sum_Sent);

?>

<!DOCTYPE html>
<html>
    <head>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

           
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

        <style>
            /*Main CSS*/
.colo{color:red;}
.col{color:green;}
tr{font-size:18px;}
th{color:white;}
    .value-positive {
              color: green;
            }

            .value-negative {
                color: #fe0000;
            }
/*Login Signup Page*/
a:focus,a:hover,a{
    outline:none;
    text-decoration: none;
}
li,ul{
    list-style: none;
    padding: 0;
    margin: 0;
}
.header-top i {
    font-size: 18px;
}
.bg-image {
    background: url(../images/background-login.jpg) no-repeat 0 0 / cover;
    position: relative;
    width: 100%;
    height: 100vh;
    display: table;
}

.login-header {
    display: inline-block;
    width: 100%;
    background: #0e1a35;
}

.login-signup {
    display: table-cell;
    vertical-align: middle;
    width: 100%;
}

.login-logo img {
    cursor: pointer;
    max-width: 171px;
    padding: 23px 15px 22px;
    width: 100%;
}

.login-header .navbar-right {
    margin-right: 0px;
}

.login-header .nav-tabs > li.active > a,
.login-header .nav-tabs > li.active > a:focus,
.login-header .nav-tabs > li.active > a:hover {
    background-color: transparent;
    border: none;
    color: #fff;
}

.login-header .nav-tabs > li > a {
    border: medium none;
    border-radius: 0;
    font-size: 14px;
    font-weight: 500;
    line-height: 48px;
    padding: 15px 30px;
    color: #fff;
}

.login-header .nav-tabs {
    border-bottom: none;
}

.login-header .nav-tabs > li {
    margin-bottom: 0px;
}

.login-header .nav > li > a:focus,
.login-header .nav > li > a:hover {
    background: none;
    text-decoration: none;
}

.login-header .nav-tabs > li.active {
    border-bottom: 6px solid #5584ff;
}

.login-inner h1 {
    color: #8492af;
    font-size: 48px;
    font-weight: 300;
    text-align: center;
    margin-top: 0;
    margin-bottom: 20px;
}

.login-inner h1 span {
    color: #5584ff;
}

.login-form {
    text-align: center;
}

.login-form input {
    -moz-border-bottom-colors: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    border-color: -moz-use-text-color -moz-use-text-color #d4d9e3;
    border-image: none;
    border-style: none none solid;
    border-width: medium medium 1px;
    font-size: 13px;
    font-weight: 300;
    width: 100%;
    color: #8492af;
    padding: 15px 50px;
    font-size: 17px;
    max-width: 550px;
}

.login-form label {
    margin-bottom: 30px;
    width: 100%;
}

.user input {
    background: rgba(0, 0, 0, 0) url("../images/user.png") no-repeat scroll 7px 12px;
}

.pass input {
    background: rgba(0, 0, 0, 0) url("../images/password.png") no-repeat scroll 7px 12px;
}

.mail input {
    background: rgba(0, 0, 0, 0) url("../images/mail.png") no-repeat scroll 4px 12px;
}

.login-signup .tab-content {
    background: #ffffff none repeat scroll 0 0;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
    display: inline-block;
    margin-top: -8px;
    width: 100%;
}

.form-btn {
    background: #5584ff none repeat scroll 0 0;
    border: medium none;
    border-radius: 100px;
    color: #ffffff;
    font-weight: 400;
    max-width: 250px;
    padding: 10px 0;
    position: relative;
    width: 100%;
    margin: 40px 0;
    box-shadow: 0 2px 8px #d2d2d2;
    -moz-box-shadow: 0 2px 8px #d2d2d2;
    -webkit-box-shadow: 0 2px 8px #d2d2d2;
}

.form-btn::before {
    content: "";
    font-family: FontAwesome;
    position: absolute;
    right: 17px;
    top: 9px;
}

.form-details {
    padding: 35px 0;
}

.tab-content .tab-pane {
    padding: 70px 0;
}


/*Login Signup Page*/


/*Home Page*/

.home {
    background: #f6f7fa;
}

#navigation {
    background: #0e1a35;
}

#navigation {
    padding: 0;
}

.display-table {
    display: table;
    padding: 0;
    height: 100%;
    width: 100%;
}

.display-table-row {
    display: table-row;
    height: 100%;
}

.display-table-cell {
    display: table-cell;
    float: none;
    height: 100%;
}

.v-align {
    vertical-align: top;
}
.logo img {
    max-width: 180px;
    padding: 16px 0 17px;
    width: 100%;
}

.header-top {
    margin: 0;
    padding-top: 2px;
}

.header-top img {
    border-radius: 50%;
    max-width: 48px !important;
    width: 100%;
}

.add-project {
    background: #5584ff none repeat scroll 0 0;
    border-radius: 100px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 27px 10px 45px;
    position: relative;
}

.header-rightside .nav > li > a:focus,
.header-rightside .nav > li > a:hover {
    background: none;
    text-decoration: none;
}

.add-project::before {
    background: rgba(0, 0, 0, 0) url("../images/plus.png") no-repeat scroll 0 0;
    content: "";
    ;
    height: 12px;
    left: 17px;
    position: absolute;
    top: 12px;
    width: 12px;
}

.add-project:hover {
    color: #ffffff;
}

.header-top i {
    color: #0e1a35;
}

.icon-info {
    position: relative;
}
.navi i {
    font-size: 20px;
}
.label.label-primary {
    border-radius: 50%;
    font-size: 9px;
    left: 8px;
    position: absolute;
    top: -9px;
}

.icon-info .label {
    border: 2px solid #ffffff;
    font-weight: 500;
    padding: 3px 5px;
    text-align: center;
}

.header-top li {
    display: inline-block;
    text-align: center;
}

.header-top .dropdown-toggle {
    color: #0e1a35;
}

.header-top .dropdown-menu {
    border: medium none;
    left: -85px;
    padding: 17px;
}
.view {
    background: #5584ff none repeat scroll 0 0;
    border-radius: 100px;
    color: #ffffff;
    display: inline-block;
    font-size: 14px;
    font-weight: 600;
    margin-top: 10px;
    padding: 10px 15px;
}

.navbar-content > span {
    font-size: 13px;
    font-weight: 700;
}

.img-responsive {
    width: 100%;
}
#navigation{
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
}
.search input {
    border: none;
    font-size: 15px;
    padding: 15px 9px;
    width: 100%;
    background: rgba(0, 0, 0, 0) url("../images/search.png") no-repeat scroll 99% 12px;
    color: #8492af;
}

header {
    background: #ffffff none repeat scroll 0 0;
    box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
    display: inline-block !important;
    line-height: 23px;
    padding: 15px;
    transition: all 0.5s ease 0s;
    width: 100%;
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
}

.logo {
    text-align: center;
}

.navi a {
    border-bottom: 1px solid #0d172e;
    border-top: 1px solid #0d172e;
    color: #ffffff;
    display: block;
    font-size: 17px;
    font-weight: 500;
    padding: 28px 20px;
    text-decoration: none;
}

.navi i {
    margin-right: 15px;
    color: #5584ff;
}

.navi .active a {
    background: #122143;
    border-left: 5px solid #5584ff;
    padding-left: 15px;
}

.navi a:hover {
    background: #122143 none repeat scroll 0 0;
    border-left: 5px solid #5584ff;
    display: block;
    padding-left: 15px;
}

.navbar-default {
    background-color: #ffffff;
    border-color: #ffffff;
}

.navbar-toggle {
    border: none;
}

.navbar-default .navbar-toggle:focus,
.navbar-default .navbar-toggle:hover {
    background-color: rgba(0, 0, 0, 0);
}

.navbar-default .navbar-toggle .icon-bar {
    background-color: #0e1a35;
}

.circle-logo {
    margin: 0 auto;
    max-width: 30px !important;
    text-align: center;
}
.hidden-xs{
    -webkit-transition: all 0.5s ease;
    -moz-transition: all 0.5s ease;
    -o-transition: all 0.5s ease;
    transition: all 0.5s ease;
}

.user-dashboard {
    padding: 0 20px;
}

.user-dashboard h1 {
    color: #0e1a35;
    font-size: 30px;
    font-weight: 500;
    margin: 0;
    padding: 21px 0;
}
.sales {
    background: #ffffff none repeat scroll 0 0;
    border: 1px solid #d4d9e3;
    display: inline-block;
    padding: 15px;
    width: 100%;
}
.sales button {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    border: 1px solid #dadee7;
    border-radius: 100px;
    font-size: 15px;
    letter-spacing: 0.5px;
    padding-right: 32px;
    color: #0e1a35;
}

.sales button::before {
    content: "";
    font-family: FontAwesome;
    position: absolute;
    right: 12px;
    top: 11px;
}
.sales  .btn-group {
    float: right;
}
.sales h2 {
    color: #8492af;
    float: left;
    font-size: 21px;
    font-weight: 600;
    margin: 0;
    padding: 9px 0 0;
}
.btn.btn-secondary.btn-lg.dropdown-toggle > span {
    font-size: 15px;
    font-weight: 600;
    letter-spacing: 0.5px;
}
.sales .dropdown-menu{
    margin: 0px;
    padding: 0px;
    border: 0px;
    border-radius: 8px;
    width: 100%;
    color: #0e1a35;
}
.sales .btn-group.open .dropdown-toggle, .btn.active, .btn:active{
    box-shadow: none;
}
.sales .dropdown-menu > a {
    color: #0e1a35;
    display: inline-block;
    font-weight: 800;
    padding: 9px 0;
    text-align: center;
    width: 100%;
}
#my-cool-chart svg {
    width: 100%;
}
.sales .dropdown-menu > a:hover{
    color: #5584FF;   
}
.shield-buttons {
    display: none;
}
.close, .close:focus, .close:hover {
    color: #fff;;
    opacity: 1;
    text-shadow: none;
}
.modal-body input {
    border: 1px solid #d4d9e3;
    font-size: 14px;
    font-weight: 300;
    margin: 5px 0;
    padding: 14px 10px;
    width: 100%;
    color: #8492af;
}
.modal-body textarea {
    border: 1px solid #d4d9e3;
    font-size: 14px;
    font-weight: 300;
    height: 200px;
    margin-top: 5px;
    padding: 9px 10px;
    width: 100%;
    color: #8492af;
}
.modal-header.login-header h4 {
    color: #ffffff;
}
.modal-footer .add-project {
    background: #5584ff none repeat scroll 0 0;
    border: medium none;
    border-radius: 100px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 30px;
    position: relative;
}
.modal-footer .add-project::before{display: none;}
.modal-footer {
    border: 0 none;
    padding: 10px 15px 26px;
    text-align: right;
}
.cancel {
    background: #0E1A35     ;
    border: medium none;
    border-radius: 100px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 30px;
    position: relative;
    
}
.modal{
    top: 20%; 
}
.modal-header .close {
    margin-top: 2px;
}
.search input:focus{
    border-bottom: 1px solid #BDC4D4;
    line-height:22px;
    transition: 0.1s all;
}
.modal-header.login-header {
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;}
/*Main CSS*/






@media only screen and (max-device-width: 767px) {
    .login-logo img {
        margin: 0 auto;
    }
    .login-details .nav-tabs > li {
        text-align: center;
        width: 50%;
    }
    .login-signup .login-inner h1 {
        font-size: 26px;
        margin-bottom: 0;
        margin-top: 10px;
    }
    .login-inner .login-form input {
        font-size: 15px;
        max-width: 100%;
        padding: 15px 45px;
    }
    .login-inner .form-details {
        padding: 25px;
    }
    .login-inner .login-form label {
        margin-bottom: 20px;
        width: 100%;
    }
    .login-inner .form-btn {
        margin: 0;
        max-width: 180px;
    }
    .tab-content .tab-pane {
        padding: 20px 0;
    }
    #navigation .navi a {
        font-size: 14px;
        padding: 20px;
        text-align: center;
    }
    #navigation .navi i {
        margin-right: 0px;
    }
    #navigation .navi a:hover,
    #navigation .navi .active a {
        background: #122143 none repeat scroll 0 0;
        border-left: none;
        display: block;
        padding-left: 20px;
    }
    header .header-top img {
        max-width: 38px !important;
    }
    .v-align header {
        padding: 12px 15px;
    }
    header .header-top li {
        padding-left: 13px;
        padding-right: 6px;
    }
    .navbar-default .navbar-toggle {
        border-color: rgba(0, 0, 0, 0);
    }
    .navbar-header .navbar-toggle {
        float: left;
        margin: 0;
        padding: 0;
        top: 12px;
    }
    button,
        html [type="button"],
        [type="reset"],
        [type="submit"] {
            outline: medium none;
    }
    .user-dashboard .sales h2 {
        color: #8492af;
        float: left;
        font-size: 14px;
        font-weight: 600;
        margin: 0;
        padding: 13px 0 0;
}
    .user-dashboard .btn.btn-secondary.btn-lg.dropdown-toggle > span {
        font-size: 11px;
}
    .user-dashboard .sales button {
        font-size: 11px;
        padding-right: 23px;
}  
    .user-dashboard .sales h2 {
    font-size: 12px;
}
.gutter{
    padding: 0;
}
}

@media only screen and (max-device-width: 992px) {
    header .header-top li {
        padding-left: 20px !important;
        padding-right: 0;
}
    header .logo img {
        max-width: 125px !important;
}

}

@media only screen and (min-device-width: 767px) and (max-device-width: 998px){
      .user-dashboard .header-top {
        padding-top: 5px;
}
    .user-dashboard .header-rightside {
        display: inline-block;
        float: left;
        width: 100%;
}
    .user-dashboard .header-rightside .header-top img {
        max-width: 41px !important;
} 
    .user-dashboard .sales button {
    font-size: 10px;
}
    .user-dashboard .btn.btn-secondary.btn-lg.dropdown-toggle > span {
    font-size: 12px;
}
    .user-dashboard .sales h2 {
    font-size: 15px;
}
}
@media only screen and (min-device-width:998px) and (max-device-width: 1350px){
        #navigation .logo img {
    max-width: 130px;
    padding: 16px 0 17px;
    width: 100%;
}
}
.column-left {
  float: left;
  width: 33.333%;
}

.column-right {
  float: right;
  width: 33.333%;
}

.column-center {
  display: inline-block;
  width: 33.333%;
}

/*a span {color:white;
/*originalcolour*/}

        </style>

    </head>

<body class="home">
     <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav mt-2 mt-lg-0">
        <li>
            <a href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <!--<li><a href="#"><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>-->
                        <!--<li><a href="#"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>-->
                        <li><a href="addCustomer.php"><i class="fa fa-user" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Add Customer</span></a></li>
                        <li><a href="viewCustomer.php"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">View Customer</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
           
    </ul> 
<!--    <div class="nav navbar-nav mt-2 mt-lg-0 pull-right">-->
            <!--<a href="#" class="nav-item nav-link">Login</a>-->
<!--            <form class="form-inline my-2 my-lg-0">-->
<!--             <input class="form-control" type="search" name="search_text" id="search_text" placeholder="Enter the year to Export" aria-label="Search">-->
<!--</form>-->
<!--</div>-->
    <div class="col-md-5">
                            <div class="header-rightside">
                                <ul class="list-inline header-top pull-right">
                                    <li class="hidden-xs">
                             <!-- Button to trigger modal -->
<button class="btn btn-danger" 
data-toggle="modal" data-target="#modalForm">
    Sent
</button>
</li>
<li><!-- Button to trigger modal -->
<button class="btn btn-success" 
data-toggle="modal" data-target="#modalLiya">
    Receive
</button>
</li>
<li class="hidden-xs">

   <!-- Button to trigger delete modal -->
<button class="btn btn-info" 
data-toggle="modal" data-target="#modalEdit">
    Edit
</button>
</li>

<li class="hidden-xs">
    
                             <!-- Button to trigger delete modal -->
<button class="btn btn-warning" 
data-toggle="modal" data-target="#modalDelete">
    Delete
</button>
</li>


<!--<li >-->
<!--    <button class="btn btn-light"-->
<!--type="button" id="btnExport" value="Export">Export</button></li>-->
<li class="hidden-xs">
    <a href="filterandexport.php?customer_id=<?php echo $page;?>" role="button" class="btn btn-primary">Filter/Export</a></li>

                            </ul>
                            </div>
                        </div>
  </div>
</nav>
    

    <div class="container-fluid display-table">
        <div class="row display-table-row">
            <!--<div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">-->
               
            <!--    <div class="navi">-->
            <!--        <ul>-->
            <!--            <li class="active"><a href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>-->
                        <!--<li><a href="#"><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>-->
                        <!--<li><a href="#"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>-->
            <!--            <li><a href="addCustomer.php"><i class="fa fa-user" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Add Customer</span></a></li>-->
            <!--            <li><a href="viewCustomer.php"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">View Customer</span></a></li>-->
            <!--            <li><a href="logout.php"><i class="fa fa-cog" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Logout</span></a></li>-->
            <!--        </ul>-->
            <!--    </div>-->
            <!--</div>-->
            <div class="col-md-10 col-sm-11 display-table-cell v-align">
                <!--<button type="button" class="slide-toggle">Slide Toggle</button> -->
<!--                <div class="row">-->
<!--                    <header>-->
<!--                        <div class="col-md-7">-->
<!--                            <nav class="navbar-default pull-left">-->
<!--                                <div class="navbar-header">-->
<!--                                    <button type="button" class="navbar-toggle collapsed" data-toggle="offcanvas" data-target="#side-menu" aria-expanded="false">-->
<!--                                        <span class="sr-only">Toggle navigation</span>-->
<!--                                        <span class="icon-bar"></span>-->
<!--                                        <span class="icon-bar"></span>-->
<!--                                        <span class="icon-bar"></span>-->
<!--                                    </button>-->
<!--                                </div>-->
<!--                            </nav>-->
<!--                            <div class="search hidden-xs hidden-sm">-->
<!--                                <input type="text" placeholder="Search" id="search">-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <div class="col-md-5">-->
<!--                            <div class="header-rightside">-->
<!--                                <ul class="list-inline header-top pull-right">-->
<!--                                    <li class="hidden-xs">-->
                             <!-- Button to trigger modal -->
<!--<button class="btn btn-danger" -->
<!--data-toggle="modal" data-target="#modalForm">-->
<!--    Diye-->
<!--</button>-->
<!--</li>-->
<!--<li><!-- Button to trigger modal -->-->
<!--<button class="btn btn-success" -->
<!--data-toggle="modal" data-target="#modalLiya">-->
<!--    Liye-->
<!--</button>-->
<!--</li>-->
<!--<li class="hidden-xs">-->
    
                             <!-- Button to trigger delete modal -->
<!--<button class="btn btn-warning" -->
<!--data-toggle="modal" data-target="#modalDelete">-->
<!--    Delete-->
<!--</button>-->
<!--</li>-->
   <!-- Button to trigger delete modal -->
<!--<button class="btn btn-info" -->
<!--data-toggle="modal" data-target="#modalEdit">-->
<!--    Edit-->
<!--</button>-->
<!--</li>-->

<!--                            </ul>-->
<!--                            </div>-->
<!--                        </div>-->
<!--                    </header>-->
<!--                </div>-->

                <div class="user-dashboard">
 <br><br>
  <?php $sqlName = "SELECT customer_name, customer_phone FROM customer where customer_id= $page";
$rs_Name = mysqli_query($db,$sqlName); 
while ($row_Name = mysqli_fetch_assoc($rs_Name)){
    $sum_Name = $row_Name['customer_name'];
    $sum_Phone = $row_Name['customer_phone'];
}
?>
                <div style="clear:both;">
         
<h4  style="align:center;">Sent: 
     <?php if(isset($sum_Sent)) echo money_format('%!i',$sum_Sent); else echo 0.00; ?>
                

                    <span>Receive:   
                    <?php if(isset($sum_Receive)) echo money_format('%!i',$sum_Receive);else echo 0.00;
                    ?></span>&nbsp;
                    <?php $classname = intval($total) < 0 ? 'negative' : 'positive';?>

Total:<span class="value-<?php echo $classname;?>"> 
        <?php  if(isset($total)) echo money_format('%!i', $total); else echo 0.00;?>
    &nbsp;<span/>
                    </h4>
                    <h3><?php echo $sum_Name;?></h3>
<h3 style="display:inline"><?php echo $sum_Phone;?>
</h3>           
    </div>
        
                    


    
    <div class="box-body table-responsive no-padding" id="order_table">
    <?php 
   
$query = "SELECT * FROM transaction_detail where customer_id= $page ORDER BY `transaction_date` ";

$result = mysqli_query($db, $query);

?>

<table class="table table-hover" id="tblCustomers">
<tr>
<th bgcolor="#4A484C"><strong>Date</strong></th>
<th bgcolor="#4A484C"><strong>Items</strong></th>
<th bgcolor="#4A484C"><strong>Sent</strong></th>
<th bgcolor="#4A484C"><strong>Receive</strong></th>
<th bgcolor="#4A484C"><strong>Total</strong></th>
<th bgcolor="#4A484C"><strong>Action</strong></th>

</tr>
                             
                     <?php  
                     while($row = mysqli_fetch_array($result)) 
                     
                     {  	       $t_id = $row["transaction_id"];
                         $currentDate =$row["transaction_date"];
                         $dateTransaction = date("d-m-Y", strtotime($row["transaction_date"]));
                     $amountS = money_format('%!i', $row["transaction_sent"]);
                     $amountR = money_format('%!i', $row["transaction_receive"]);
$sql_Re = "SELECT SUM(transaction_receive)-SUM(transaction_sent) AS re FROM transaction_detail where transaction_date<'$currentDate' AND customer_id=$page";  
$result_Re = mysqli_query($db,$sql_Re); 
while ($row_St = mysqli_fetch_assoc($result_Re)){
   $sum_St = $row_St['re'];
}

$amountT = money_format('%!i', ($sum_St+($row["transaction_receive"]-$row["transaction_sent"])));


                     ?>  
                          <tr>
                              <td><?php echo $dateTransaction;?></td>
<td><?php echo strtoupper($row["transaction_detail"]);?></td>
<td class="colo"><?php if($amountS==0.00) echo '...'; else echo $amountS ;?></td>
<td class="col"><?php if($amountR==0.00) echo '...'; else echo $amountR;?></td>
              <?php $classname = intval($amountT) < 0 ? 'negative' : 'positive';?>

<td class="value-<?php echo $classname;?>"><?php echo $amountT;?></td>
<td>
<a onclick="return confirm('Delete this record?')"
href="deleterecord.php?customer_id=<?php echo $page;?>&t_id=<?php echo $t_id;?>">Delete</a>
</td>
</tr>
 
                     <?php  
                     		
unset($amountT);}  
                     ?>  
                     </table>  
                </div>  
</div>

                   
            
            </div>
        </div>

    </div>



                <form role="form" method="post">

<!-- Modal Diya-->
<div class="modal fade" id="modalForm" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Diya</h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="statusMsg"></p>
                    <div class="form-group">
                        <label for="inputName">Amount</label>
                        <input type="number" class="form-control" id="inputName" placeholder="Enter your amount" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">Item</label>
                        <input type="text" class="form-control" id="inputEmail" placeholder="Enter items" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputMessage">Date</label>
                        <input type="date" class="form-control" id="inputMessage" placeholder="Enter date" required/>
                    </div>
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button value="button" class="btn btn-primary submitBtn" 
onclick="submitContactForm(event);">SUBMIT</button>
            </div>
        </div>
    </div>
</div>
                </form>

 <!--Modal Liya-->
                 <form role="form" action="post">

<div class="modal fade" id="modalLiya" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
             <!--Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Liya</h4>
            </div>
            
             <!--Modal Body -->
            <div class="modal-body">
                <p class="statusMsg"></p>
                    <div class="form-group">
                        <label for="inputAmount">Amount</label>
                        <input type="number" class="form-control" id="inputAmount" placeholder="Enter your amount" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputItem">Item</label>
                        <input type="email" class="form-control" id="inputItem" placeholder="Enter items" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputDate">Date</label>
                        <input type="date" class="form-control" id="inputDate" placeholder="Enter the date" required/>
                    </div>
            </div>
            
             <!--Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button  class="btn btn-primary submitBtn" onclick="submitReceiveForm(event);">SUBMIT</button>
            </div>
        </div>
    </div>
</div>
                </form>

<!-- give and take modal form-->


<!-- Modal Delete -->
                <form role="form" method="post">

<div class="modal fade" id="modalDelete" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Data Hataye</h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="statusMsg"></p>
                    <div class="form-group">
                        <label for="inputStartDate">Start Date</label>
                        <input type="date" class="form-control" id="inputStartDate" placeholder="Enter start date" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputEndDate">End Date</label>
                        <input type="date" class="form-control" id="inputEndDate" placeholder="Enter last date" required/>
                    </div>
                    
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary submitBtn" 
onclick="submitDeleteForm(event);">Delete</button>
            </div>
        </div>
    </div>
</div>
                </form>

<!-- Modal Edit -->
<div class="modal fade" id="modalEdit" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Edit Kare</h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="statusMsg"></p>
                <form role="form" method="post">
                    <div class="form-group">
                        <label for="inputEditName">Name</label>
                        <input type="text" class="form-control" id="inputEditName" placeholder="Enter Name" value="<?php echo $sum_Name; ?>" required/>
                    </div>
                    <div class="form-group">
                        <label for="inputEditNumber">Phone Number</label>
                        <input type="Number" class="form-control" id="inputEditNumber" placeholder="Enter Phone Number"  max="9999999999" min="1000000000" value="<?php echo $sum_Phone; ?>"required/>
                    </div>
                    
                </form>
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary submitBtn" 
onclick="submitEditForm(event);">Update</button>
            </div>
        </div>
    </div>
</div>

<script>


function submitContactForm(event){
            event.preventDefault();

    var name = $('#inputName').val();
    var email = $('#inputEmail').val();
    var message = $('#inputMessage').val();
    var customer = <?php echo $page; ?>;
if (!$('#inputName').val() || !$('#inputEmail').val() || !$('#inputMessage').val()) {
  return alert('Please fill in all required fields.');
}
        $.ajax({
            type:'POST',
            url:'submit_form.php',
            data:'contactFrmSubmit=1&name='+name+'&customer='+customer+'&email='+email+'&message='+message,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputName').val('');
                    $('#inputEmail').val('');
                    $('#inputMessage').val('');
                    $('.statusMsg').html('<span style="color:green;">Sent ho gya</p>');
                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                    window.location.reload();

            }
        });
        

    }

</script>
<!--Form for receiving-->
<script>

function submitReceiveForm(event){
        event.preventDefault();

    var name = $('#inputAmount').val();
    var email = $('#inputItem').val();
    var message = $('#inputDate').val();
    var customer = <?php echo $page; ?>;
if (!$('#inputAmount').val() || !$('#inputItem').val() || !$('#inputDate').val()) {
  return alert('Please fill in all required fields.');
}

        $.ajax({
            type:'POST',
            url:'submit_form.php',
            data:'receiveFrmSubmit=1&name='+name+'&customer='+customer+'&email='+email+'&message='+message,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputAmount').val('');
                    $('#inputItem').val('');
                    $('#inputDate').val('');
                    $('.statusMsg').html('<span style="color:green;">Receive ho gya</p>');
                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                    window.location.reload();

            }
        });
        

    }

</script>
<!--Form for deleting-->

<script>

function submitDeleteForm(event){
                event.preventDefault();

    var startDate = $('#inputStartDate').val().split("/").reverse().join("-");
    var endDate = $('#inputEndDate').val().split("/").reverse().join("-");

    var customer = <?php echo $page; ?>;
if (!$('#inputStartDate').val() || !$('#inputEndDate').val()) {
  return alert('Please fill in all required fields.');
}
        $.ajax({
            type:'POST',
            url:'submit_form.php',
            data:'deleteFrmSubmit=1&startDate='+startDate+'&customer='+customer+'&endDate='+endDate,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputStartDate').val('');
                    $('#inputEndDate').val('');            

                    $('.statusMsg').html('<span style="color:green;">Delete ho gya</p>');                    window.location.reload();

                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');

            }
        });
        

    }

</script>
<!--Form for editing-->


<script>

 
function submitEditForm(event){
                event.preventDefault();

    var name = $('#inputEditName').val();
    var number = $('#inputEditNumber').val();
    var customer = <?php echo $page; ?>;
if (!$('#inputEditName').val() || !$('#inputEditNumber').val()) {
  return alert('Please fill in all required fields.');
}
        $.ajax({
            type:'POST',
            url:'submit_form.php',
            data:'editFrmSubmit=1&name='+name+'&customer='+customer+'&number='+number,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputEditName').val('');
                    $('#inputEditNumber').val('');            

                    $('.statusMsg').html('<span style="color:green;">Edit ho gya</p>');                    window.location.reload();

                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');

            }
        });
        

    }

</script>
<script lang='javascript'>
 $(document).ready(function(){
  
    $('INPUT').keydown( e => e.which === 13?$(e.target).next().focus():"");

 //confirmation for deleting the record
 
   $('a.delete').on('click', function() {
    var choice = confirm('Do you really want to delete this record?');
    if(choice === true) {
        return true;
    }
    return false;
});  
 });

</script
<!-- AJAX search code -->
<!--<script lang='javascript'>-->
<!--$(document).ready(function(){-->
    
<!--	load_data();-->
<!--	function load_data(query)-->

<!--	{   var customerId = <?php echo $page; ?>; -->

	   
<!--		$.ajax({-->
<!--			url:"fetchTransaction.php",-->
<!--			method:"post",-->
		
<!--	data:{query:query, customerId:customerId},-->
<!--			success:function(data)-->
			
<!--{-->
<!--				$('#result').html(data);-->
<!--			}-->
<!--		});-->
<!--	}-->
	

<!--	$('#search_text').keyup(function(){-->
<!--		var search = $(this).val();-->
<!--		if(search != '')-->
	
<!--	{-->
<!--			load_data(search);-->
<!--		}-->
<!--		else-->
	
<!--	{alert(customerId);-->
	  
<!--			load_data(customerId);		-->
<!--		}-->
<!--	});-->
	
	
	
	
	
<!--});-->
<!--</script>-->
<!--For exporting the pdf-->
  <!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>-->
  <!--  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>-->
  <!--  <script type="text/javascript">-->
  <!--      $("body").on("click", "#btnExport", function () {-->
  <!--          html2canvas($('#result')[0], {-->
  <!--              onrendered: function (canvas) {-->
  <!--                  var data = canvas.toDataURL();-->
  <!--                  var docDefinition = {-->
  <!--                      content: [{-->
  <!--                          image: data,-->
  <!--                          width: 500-->
  <!--                      }]-->
  <!--                  };-->
  <!--                  pdfMake.createPdf(docDefinition).download("cutomer-details.pdf");-->
  <!--              }-->
  <!--          });-->
  <!--      });-->
  <!--  </script>-->




</body>
</html>