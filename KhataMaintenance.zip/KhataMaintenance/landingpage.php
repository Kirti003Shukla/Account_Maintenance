<?php

require 'configuration.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST["device"])&& (isset($_POST["firmware"])) && (isset($_FILES['uploadedFile']))) {
    
     $device =  $_POST["device"];
      $firmware = $_POST["firmware"];
      $dt1=date("Y-m-d");

  
    // get details of the uploaded file
$fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
$fileName = $_FILES['uploadedFile']['name'];
$fileSize = $_FILES['uploadedFile']['size'];
$fileType = $_FILES['uploadedFile']['type'];

$target_dir = "uploads/"; 
$target_file = $target_dir . basename($_FILES["uploadedFile"]["name"]); 

  $sql = "INSERT INTO gw_table (device, firmware_version, firmware_file,created_at)
  VALUES ('$device', '$firmware', '$target_file','$dt1')";
  // use exec() because no results are returned
  $conn->exec($sql);
  move_uploaded_file($_FILES["uploadedFile"]["tmp_name"], 
                                            $target_file);
    echo "<script>alert('Successfully uploaded');</script>";

  }
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style>.bk-clr{background-color: #F5F5F5; margin:15px;   }
      .bk-colour{background-color:  #18AA75;}</style>
    </head>
    <body class="bk-clr">
        <div class="container-fluid bk-clr">
            <div class="form-control bk-colour" >
<h3>File Upload</h3>
</div>

            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">  

            <div class="row">
<div class=" mb-3 col-12">
  <label class="form-label" for="inputGroupSelect01">Device Model</label>
  <select class="form-select form-control" id="inputGroupSelect01" name="device" required>
    <option selected>..Select Device..</option>
    <option value="1">One</option>
    <option value="2">Two</option>
    <option value="3">Three</option>
  </select>
</div>
            </div>
              <div class="row">

  <div class="col-md-5">
    <label for="Firmware" class="form-label">Firmware version</label>
    <input type="text" class="form-control" id="Firmware" name="firmware" required>
  </div>
  

      <div class="col-md-7">
              <label class="form-label" for="customFileLang">Select Firmware</label>

  <input type="file" class=" form-control" id="customFileLang" name="uploadedFile" lang="es" required>
</div>
              </div>  
			<div > 
				<button type="submit" class="btn btn-primary btn-block .btn-blk mt-2">Upload</button> 
                        </div>
</form>
        </div>
                <div class=" container-fluid mt-4">
<div class="form-control bk-colour" >
<h3>Firmware Table</h3>
</div>
                   
        <table class="table bk-clr">
  <thead>
    <tr>
      <th>GWX</th>
      <th>Firmware</th>
      <th>Filepath</th>
      <th>Created at</th>
    </tr>
  </thead>
  <tbody>
       <?php 
       
         $stmt = $conn->query("SELECT * FROM gw_table");
  $data = $conn->query("SELECT * FROM gw_table")->fetchAll();
// and somewhere later:
foreach ($data as $row) {
    



                    
                    ?>

    <tr>
      <th scope="row"><?= $row['device']; ?></th>
      <td><?= $row['firmware_version']; ?></td>
      <td><?= $row['firmware_file']; ?></td>
      <td><?= $row['created_at']; ?></td>
    </tr>
<?php }?>
  </tbody>
</table>
</div> 
   <?php
        // put your code here
        ?>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
</html>
