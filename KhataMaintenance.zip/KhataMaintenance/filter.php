<?php  
 //filter.php  
 include("config.php");
setlocale(LC_MONETARY, 'en_IN');

 if(isset($_POST["from_date"], $_POST["to_date"], $_POST["customerId"]))  
 {   $page =$_POST["customerId"];
 $from_date = date("Y-m-d", strtotime($_POST["from_date"]));
 $to_date =  date("Y-m-d", strtotime($_POST["to_date"]));
$to_date.=' 23:59:59';
      $output = '';  
      $query = "  
           SELECT * FROM transaction_detail  
           WHERE  customer_id=$page AND transaction_date BETWEEN '$from_date' AND '$to_date' ORDER BY transaction_date";  
      $result = mysqli_query($db, $query);  
       $sqlName = "SELECT customer_name, customer_phone FROM customer where customer_id= $page";
$rs_Name = mysqli_query($db,$sqlName); 
while ($row_Name = mysqli_fetch_assoc($rs_Name)){
    $sum_Name = $row_Name['customer_name'];
    $sum_Phone = $row_Name['customer_phone'];
}

	$output .= '<h3 style="display:inline">'. $sum_Name.'</h3>
<h3>'.$sum_Phone.'</h3><table class="table table-hover" id="tblCustomers">
<tr>
<th bgcolor="#4A484C"><strong>Date</strong></th>
<th bgcolor="#4A484C"><strong>Items</strong></th>
<th bgcolor="#4A484C"><strong>Sent</strong></th>
<th bgcolor="#4A484C"><strong>Receive</strong></th>
<th bgcolor="#4A484C"><strong>Total</strong></th>
</tr>  
';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
             {  $currentDate =$row["transaction_date"];

                $output .= '<tr>
                     <td>'.date("d-m-Y", strtotime($row["transaction_date"])).'</td>
<td>'.strtoupper($row["transaction_detail"]).'</td>';
$amountS = money_format('%!i', $row["transaction_sent"]);

	$output .= '<td class="colo">'. $amountS .'</td>';
$amountR = money_format('%!i', $row["transaction_receive"]);
$output .= '<td class="col">'. $amountR.'</td>';
$sql_Re = "SELECT SUM(transaction_receive)-SUM(transaction_sent) AS re FROM transaction_detail where transaction_date<'$currentDate' AND customer_id=$page";  
$result_Re = mysqli_query($db,$sql_Re); 
while ($row_St = mysqli_fetch_assoc($result_Re)){
   $sum_St = $row_St['re'];
}
$amountT = money_format('%!i', ($sum_St+($row["transaction_receive"]-$row["transaction_sent"])));

$output .= '<td>'.$amountT.'
</td>
                        
                ';  
           }  
      }  
      else  
      {  
           $output .= '  
                <tr>  
                     <td colspan="5">No Order Found</td>  
                </tr>  
           ';  
      }  
      $output .= '</table>';  
      echo $output;  
 }  
 ?>

