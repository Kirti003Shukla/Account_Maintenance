<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'rkpummjg');
   define('DB_PASSWORD', 'Dadcp@nel#123');
   define('DB_DATABASE', 'rkpummjg_km');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   		if (!$db) {
			echo "<p>Could not connect to the server</p>\n";
        	echo mysqli_error();
		}
?>
