<!DOCTYPE html>
<html>
<title>Resume</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>
<body class="w3-light-grey">

<!-- Page Container -->
<div class="w3-content w3-margin-top" style="max-width:1400px;">

  <!-- The Grid -->
  <div class="w3-row-padding">
  
    <!-- Left Column -->
    <div class="w3-third">
    
      <div class="w3-white w3-text-grey w3-card-4">
        <div class="w3-display-container">
          <img src="WhatsApp Image 2020-12-28 at 12.29.34 PM.jpeg
" style="width:100%" height=400 alt="Avatar">
          <div class="w3-display-bottomleft w3-container w3-text-white">
            <h2>Kirti Shukla</h2>
          </div>
        </div>
        <div class="w3-container">
          <p><i class="fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-teal"></i>Web Developer</p>
          <p><i class="fa fa-home fa-fw w3-margin-right w3-large w3-text-teal"></i>Kanpur, UP</p>
          <p><i class="fa fa-envelope fa-fw w3-margin-right w3-large w3-text-teal"></i>kirti.bhumca2015@gmail.com</p>
          <p><i class="fa fa-phone fa-fw w3-margin-right w3-large w3-text-teal"></i>7022974869</p>
          <hr>

          <p class="w3-large"><b><i class="fa fa-asterisk fa-fw w3-margin-right w3-text-teal"></i>Skills</b></p>
          <p>HTML,CSS</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-teal" style="width:80%">80%</div>
          </div>
          <p>Php,MySql</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-teal" style="width:90%">
              <div class="w3-center w3-text-white">90%</div>
            </div>
          </div>
          <p>Javascript,Jquery</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-teal" style="width:75%">75%</div>
          </div>
          <p>Bootstrap,Ajax</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-teal" style="width:70%">70%</div>
          </div>
          <br>

          <p class="w3-large w3-text-theme"><b><i class="fa fa-globe fa-fw w3-margin-right w3-text-teal"></i>Languages</b></p>
          <p>English</p>
          <div class="w3-light-grey w3-round-xlarge">
            <div class="w3-round-xlarge w3-teal" style="height:24px;width:100%"></div>
          </div>
          <p>Hindi</p>
          <div class="w3-light-grey w3-round-xlarge">
            <div class="w3-round-xlarge w3-teal" style="height:24px;width:100%"></div>
          </div>
          <!--<p>German</p>-->
          <!--<div class="w3-light-grey w3-round-xlarge">-->
          <!--  <div class="w3-round-xlarge w3-teal" style="height:24px;width:25%"></div>-->
          <!--</div>-->
          <br>
        </div>
      </div><br>

    <!-- End Left Column -->
    </div>

    <!-- Right Column -->
    <div class="w3-twothird">
    
      <div class="w3-container w3-card w3-white w3-margin-bottom">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-suitcase fa-fw w3-margin-right w3-xxlarge w3-text-teal"></i>Work Experience</h2>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Freelancer Web Developer</b></h5>
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Aug 2020 - <span class="w3-tag w3-teal w3-round">Current</span></h6>
          <p><a href="www.rkpump.com">R&K Pumps</a></p>
                    <p><a href="http://khatabookmaintenance.rkpump.com/KhataMaintenance/">Khatabook Maintenance</a></p>
          <hr>
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Web Developer Intern/ GAC Consultants</b></h5>
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Feb 2020 - Aug 2020</h6>
          <p><a href="https://xperthunt.com">Xperthunt</a></p>
          <hr>
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Associate Recruiter/ Talville</b></h5>
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>April 2019 - Nov 2019</h6>
          <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p><br>-->
        </div>
      </div>

      <div class="w3-container w3-card w3-white">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-certificate fa-fw w3-margin-right w3-xxlarge w3-text-teal"></i>Education</h2>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>IIT Kanpur</b></h5>
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Nov 2019- Feb 2020</h6>
          <p>Online Full Stack Developer Certificate Course</p>
          <hr>
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Banaras Hindu University</b></h5>
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>2015 - 2018</h6>
          <p>Master of Computer Applications</p>
          <hr>
        </div>
        <!--<div class="w3-container">-->
        <!--  <h5 class="w3-opacity"><b>School of Coding</b></h5>-->
        <!--  <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>2010 - 2013</h6>-->
        <!--  <p>Bachelor Degree</p><br>-->
        <!--</div>-->
      </div>

    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
  <!-- End Page Container -->
</div>

<footer class="w3-container w3-teal w3-center w3-margin-top">
  <p>Find me on social media.</p>
  <!--<i class="fa fa-facebook-official w3-hover-opacity"></i>-->
  <!--<i class="fa fa-instagram w3-hover-opacity"></i>-->
  <!--<i class="fa fa-snapchat w3-hover-opacity"></i>-->
  <!--<i class="fa fa-pinterest-p w3-hover-opacity"></i>-->
  <!--<i class="fa fa-twitter w3-hover-opacity"></i>-->
  <a href="https://www.linkedin.com/in/kirti-shukla-2455b9ba/"><i class="fa fa-linkedin w3-hover-opacity"></i></a>
  <!--<p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>-->
</footer>

</body>
</html>
