<?php
include('config.php');   


if(isset($_POST['loginFrmSubmit']) && !empty($_POST['email']) &&  !empty($_POST['password']))
{ //                           $status ='ok';

  $email  =  mysqli_real_escape_string($db,$_POST['email']);
  $password =  mysqli_real_escape_string($db,$_POST['password']);

  
    $sql_query = "select * FROM register where email='".$email."'";
    $result = mysqli_query($db,$sql_query);
    
    if (mysqli_num_rows($result) > 0) {                           


      while($row = mysqli_fetch_array($result))

      {
          $username = $row['username'];
        $hashed_password = $row['password'];
      }// $status =$hashed_password;

                // Check if username exists, if yes then verify password
                
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["username"] = $username;                            
                            $status =22;
}
}
else{
     $status = 'err';
    
}
                    
        
    
    echo $status;


}
?>

