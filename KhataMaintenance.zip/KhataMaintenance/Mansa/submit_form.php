<?php
include('config.php');   

if(isset($_POST['contactFrmSubmit']) && !empty($_POST['fullname']) && !empty($_POST['username']) && !empty($_POST['email']) && !empty($_POST['password']) ){
//&& !empty($_POST['base64data'])
// Submitted form data
    $fullname   =  mysqli_real_escape_string($db,$_POST['fullname']);
    $username =  mysqli_real_escape_string($db,$_POST['username']);
    $email  =  mysqli_real_escape_string($db,$_POST['email']);
    $password =  mysqli_real_escape_string($db,$_POST['password']);
        $profilepic =  'ghghfhhdghf';
        //mysqli_real_escape_string($db,$_POST['base64data']);


                $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash


  	$query = "INSERT INTO `register` (`fullname`, `username`, `email`, `password`, `profilepic`) VALUES('$fullname', '$username', '$email', '$param_password', '$profilepic')";

  	mysqli_query($db, $query);

    if(mysqli_affected_rows($db))
{
        $status =23;
}else{
        $status = 'err';
    }
    
    // Output status
    echo $status;
}
?>


