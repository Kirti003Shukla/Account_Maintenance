<?php include('config.php');

if(isset($_GET['customer_id']) && isset ($_GET['t_id'])){
    
    // Submitted form data

    $transaction_id = $_GET['t_id'];
     $customer_id = $_GET['customer_id'];
  

  	$query = "DELETE FROM `transaction_detail` WHERE customer_id=$customer_id AND transaction_id=$transaction_id";
  	mysqli_query($db, $query);
//   	$queryDelete = "DELETE FROM `customer` WHERE customer_id=$customer_id";
//   	mysqli_query($db, $query);
//   	  	mysqli_query($db, $queryDelete);



    // if(mysqli_affected_rows($db))
   { header("location:transactions.php?customer_id=$customer_id"); }
    }
    ?>