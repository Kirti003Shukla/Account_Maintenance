<?php  
session_start();
include("config.php");
            if(!isset($_SESSION['user']))
            {header("location:index.php");}
            
if (isset($_GET["customer_id"]))
    {  
        $page = $_GET["customer_id"]; 
    }
    setlocale(LC_MONETARY, 'en_IN');

$query = "SELECT * FROM transaction_detail where customer_id= $page ORDER BY `transaction_date` ";
$result = mysqli_query($db,$query); 
 
 $sql_Sent = "SELECT SUM(transaction_sent) AS sent FROM transaction_detail where customer_id=$page";  
$result_Sent = mysqli_query($db,$sql_Sent); 
$sql_Receive = "SELECT SUM(transaction_receive) AS receive FROM transaction_detail where customer_id=$page";  
$result_Receive = mysqli_query($db,$sql_Receive); 

while ($row_Sent = mysqli_fetch_assoc($result_Sent)){
   $sum_Sent = $row_Sent['sent'];
}


while ($row_Receive = mysqli_fetch_assoc($result_Receive)){
    $sum_Receive = $row_Receive['receive'];
}


$total = ($sum_Receive-$sum_Sent);
 
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Filter and Export</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
             <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" >

           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
           <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">  
           <style>
            /*Main CSS*/
.colo{color:red;}
.col{color:green;}
tr{font-size:18px;}
th{color:white;}
   .home{ background: #f6f7fa;}
    .value-positive {
              color: green;
            }

            .value-negative {
                color: #fe0000;
            }

</style>
      </head>  
      <body class="home">  <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav mt-2 mt-lg-0">
        <li class="active"><a href="transactions.php?customer_id=<?php echo $page;?>"><i class="fa fa-arrow-left" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Transactions</span></a></li>
        <li>
            <a href="dashboard.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <!--<li><a ><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>-->
                        <!--<li><a href="#"><i class="fa fa-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>-->
                        <li><a href="addCustomer.php"><i class="fa fa-user" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Add Customer</span></a></li>
                        <li ><a href="viewCustomer.php"><i class="fa fa-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">View Customer</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
           
    </ul>
<!--<div class="nav navbar-nav mt-2 mt-lg-0 pull-right">-->
            <!--<a href="#" class="nav-item nav-link">Login</a>-->
<!--            <form class="form-inline my-2 my-lg-0">-->
<!--             <input class="form-control" type="search" name="search_text" id="search_text" placeholder="Enter the year to Export" aria-label="Search">-->
<!--</form>-->
<!--</div>-->
    <div class="col-md-5 ">
                            <div class="header-rightside">
                    
                            <div class="col-md-3">  
                     <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" />  
                </div>  
                <div class="col-md-3">  
                     <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" />  
                </div>  
                <div class="col-md-5">  
                     <!--<input type="button" name="filter" id="filter" value="Filter" class="btn btn-info" /> -->
                     <button type="button" name="filter" id="filter" value="Filter" class="btn btn-info"><i class="fa fa-filter"></i> Filter</button>
<button type="button" class="btn btn-dark" id="btnExport" value="Export"><i class=" fa fa-download" aria-hidden="true"></i> Export</button>
               

                </div>  

                <!--<div style="clear:both"></div> -->
                            </div>
                        </div>
  </div>
</nav>
           <br /><br />  
           <div class="container" style="width:900px;">
  
                <!--<h2 align="right">Date Range Search <span>Order Data</span></h2>  -->

                <br />  
<div class="box-body table-responsive no-padding" id="order_table">
    <?php $sqlName = "SELECT customer_name, customer_phone FROM customer where customer_id= $page";
$rs_Name = mysqli_query($db,$sqlName); 
while ($row_Name = mysqli_fetch_assoc($rs_Name)){
    $sum_Name = $row_Name['customer_name'];
    $sum_Phone = $row_Name['customer_phone'];
}
?>

<h4  style="align:center;">Sent: 
     <?php if(isset($sum_Sent)) echo money_format('%!i',$sum_Sent); else echo 0.00; ?>
                

                    <span>Receive:   
                    <?php if(isset($sum_Receive)) echo money_format('%!i',$sum_Receive);else echo 0.00;
                    ?></span>&nbsp;<?php $classname = intval($total) < 0 ? 'negative' : 'positive';?>

Total:<span class="value-<?php echo $classname;?>"> 
        <?php  if(isset($total)) echo money_format('%!i', $total); else echo 0.00;?>
    &nbsp;<span/>
                    </h4>
                    <h3><?php echo $sum_Name;?></h3>
<h3 style="display:inline"><?php echo $sum_Phone;?>
</h3>
<!--	<h3 style="display:inline"><?php //echo $sum_Name;?></h3>-->
<!--<h3 style="display:inline"><?php //echo $sum_Phone;?></h3>-->
<table class="table table-hover" id="tblCustomers">
<tr>
<th bgcolor="#4A484C"><strong>Date</strong></th>
<th bgcolor="#4A484C"><strong>Items</strong></th>
<th bgcolor="#4A484C"><strong>Sent</strong></th>
<th bgcolor="#4A484C"><strong>Receive</strong></th>
<th bgcolor="#4A484C"><strong>Total</strong></th>
</tr>
                             
                     <?php  
                     while($row = mysqli_fetch_array($result))  
                     {  $currentDate =$row["transaction_date"];
                         $dateTransaction = date("d-m-Y", strtotime($row["transaction_date"]));
                     $amountS = money_format('%!i', $row["transaction_sent"]);
                     $amountR = money_format('%!i', $row["transaction_receive"]);
$sql_Re = "SELECT SUM(transaction_receive)-SUM(transaction_sent) AS re FROM transaction_detail where transaction_date<'$currentDate' AND customer_id=$page";  
$result_Re = mysqli_query($db,$sql_Re); 
while ($row_St = mysqli_fetch_assoc($result_Re)){
   $sum_St = $row_St['re'];
}

$amountT = money_format('%!i', ($sum_St+($row["transaction_receive"]-$row["transaction_sent"])));


                     ?>  
                          <tr>
                              <td><?php echo $dateTransaction;?></td>
<td><?php echo strtoupper($row["transaction_detail"]);?></td>
<td class="colo"><?php echo $amountS ;?></td>
<td class="col"><?php echo $amountR;?></td>
<td><?php echo $amountT;?></td>

</tr>
 
                     <?php  
                     		
unset($amountT);}  
                     ?>  
                     </table>  
                </div>  
           </div>  
 <script>  
      $(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val(); 
                var customerId = <?php echo $page; ?>;                     

                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"filter.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date, customerId:customerId},  
                          success:function(data)  
                          {  
                               $('#order_table').html(data);  
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });  
      });  
 </script>

    <br />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script type="text/javascript">
        $("body").on("click", "#btnExport", function () {
            html2canvas($('#order_table')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("cutomer-details.pdf");
                }
            });
        });
    </script>
      </body>  
 </html>  
